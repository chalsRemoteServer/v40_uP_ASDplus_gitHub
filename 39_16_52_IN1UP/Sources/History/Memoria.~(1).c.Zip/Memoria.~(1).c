/*
 * Memoria.c
 *
 *  Created on: Mar 9, 2017
 *      Author: chals
 */


/*
�'
0�+} * MemoConfig.c
 *
 *  Created on: Jul 15, 2015
 *      Author: chals
 */

#include "Memoria.h"
#include "VFDmenu.h"
#include "Reloj.h"
#include "system.h"
#include "I2C_.h"
#include "errorController.h"
#include "delay.h"
#include "frecqController.h"
#include "VFD.h"
#include "DSP.h"


#define INITIALIZED_MEMO_VARS  //INDICA QUE YA SE inzializaron las variables que sacamos de la EEPROM
#define EEPROM_ADD_BIOS  I2CBUFSIZE+2
#define NVRAM_ADD_BIOS   0x09 //DIRECCIOnes de uso general en NVRAM 08 al 3Fh

/*#define  TACO    1
#define FOTOCEL  2
#define RECHAZO  3
#define PRODUCTO 4
#define AUX1     5
#define AUX2     6*/


struct EntSyst{ 
		unsigned char taco;	
		unsigned char fotocel;
		unsigned char rechazo;
		unsigned char producto; 
		unsigned char aux1;
		unsigned char aux2;
		unsigned char byten;	
}EntradasSistemaReg;

struct DiagnosticoErrores{
	
	   unsigned short int label;
	   unsigned short int number;
};

struct SEMAFOROS{
	   unsigned char I2Cdevice;//cual dispositivo se esta usando
	   unsigned char operacion;//que se le va hacer
	   unsigned char *p;//puntador de datos
	   unsigned char semTemporizado;
}Sem;

 
unsigned char modificado; //guarda cual menu ha sido mosificado
//EntSyst EntradasSistemaReg; //estructura que guarda las variables de entrada de sistema
unsigned char IDcomm; //ID  de comunicaciones, variable
unsigned char Alta; //variable que guarda el ultimo digito de la frecuencia alta
unsigned char Media;//variable que guarda el ultimo digito de la frecuencia media
unsigned char Baja;//variable que guarda el ultimo digito de la frecuencpia baja
unsigned char PSU_ES;  //Power supply unit  ENTRADAS SALIDAS variable AJUSTE_DE_SISTEMA/INGENIERIA GRACIDA/INGENIERIA GRACIDA2
unsigned char ErrorRelojAnalogo;//variable AJUSTE_DE_SISTEMA/INGENIERIA GRACIDA/INGENIERIA GRACIDA2
unsigned char ReporteProductos;// variable menu AJUSTE_DE_SISTEMA/INGENIERIA GRACIDA/INGENIERIA_GRACIDA2
unsigned char CuentaProducto; //variable de activacion de  cuenta de producto
unsigned char ControlContrasena1,ControlContrasena2,ControlContrasena3,ControlContrasena4;
unsigned char Control_de_usuario; //VARIABLE que guarda el control de usuario de /AJUSTE_DE_SISTEMA/MENU_ADMINISTRATIVO/control_de_usuario                                    
unsigned char Guardia; // variable de guardia en /AJUSTE_DE_SISTEMA/MENU_ADMINSTRATIVO/Ajuste_de_Guardia
unsigned char tipo_deMaquina; // garda el tipo de maquina que esta configurado
unsigned char GananciaDriver; //ganancia de la driver en AJUSTE_DE_SISTEMA/INGENIERIA_GRACIDA/GANANCIA
unsigned char GananciaAnaloga;//ganancia de la analoga en  AJUSTE_DE_SISTEMA/INGENIERIA_GRACIDA/GANANCIA
unsigned char filtroConfig; // variable filtro  de filtro en ingenieria  gracida
unsigned char PSUIOconfig; // confifura si permite o no las salidas/entradas en la tarjeta IO
unsigned char errorAnalogoPerm; // permitir error analogo
unsigned char ReporteProductoPerm; //permitir reporte de producto
unsigned char BorrarContadores; //variable que indica si se borran los contadores
unsigned char frecuenciaSeleccion;//SELECCIONA EL NIVEL de la frecuencia actual configurada y activada
unsigned long int frecuency; //guarda el valor actual de la frecuencia activada
unsigned int  Sensibilidad; // variable de sensibilidad, Sensibilidad2 es la misma variable
unsigned char phase,phasefrac;//phase de ajustes de deteccion la variable fraccionaria es de la misma vriable
unsigned int  Altura; //variable de parametros de deteccion------para el DDS
unsigned char MarcarAltura; //variable de parametros de deteccion para el DDS
unsigned char GananciaDDS; //ganancia del DDS, esta no se ha guardado
unsigned char ZoomDDS; //variable que guarda el Zoom actual en la DDS del producto actual
unsigned char cuadritoDDS; //variable cuadrito poco estudiada
unsigned char errorLista[SIZE_ERROR]; //guarda el estado de los errores y cada  byte es un error
unsigned char statusFactory; //nos dice si la memoria ha sido inizializada con setup
unsigned char indiceProducto; //Producto Set TestUP=1, que producto esta actualmete seleccionado
unsigned char name[NOMBRE_PRODUCTO_SIZE]; 
unsigned char Parte11AnalogVer;//guarda la version de la Analoga que vamos a controlar

unsigned char EEPROM[1500];
extern unsigned char realTimeError;//guarda el error que se despliega en pantalla en tiempo real

//funciones externas
extern void displayEEPROMdata1(unsigned char *p);
extern void init_AnalogGainControl(void);
extern unsigned char Text[NOMBRE_PRODUCTO_SIZE];//texto que regresa  del procesador de textos
extern unsigned char igxm,igxm4; //variable generica gloabal activa solo mientras esta activo el menu actual


char  writeReadEEprom(void){// funciones del BIOS para escribir y leer la EEPROM y revisar que funcinoes
 unsigned char   a[]="prueba_de_BIOS", *p,i,k;
       p=&a[0];
       writeEEPROM(p,EEPROM_ADD_BIOS,sizeof(a));
       displayCountingBIOS_(_EEPROM_); 
       p=readEEPROM(EEPROM_ADD_BIOS,sizeof(a));
       k=(unsigned char)sizeof(a);//n lo convierte bien si no lo pones asi
       for(i=0;i<k;i++)
    	   if(*(p+i)!=a[i]){
    		     I2CliberarModulo();
    		     return FALSE;} 
       I2CliberarModulo();	  
       return TRUE;	   

}/// fin evaluar memOroria EEPROM

char writeReadNVRAM(void){//Funcion para la BIOS write and read and check performance
unsigned char *p,i=0;//son 30 espacions hrizontal, 6 renglones  	
unsigned char a[]={2,3,4,5,6,7,8,9};
    pruebaI2C();
	displayCountingBIOS_(_NVRAM_); 
	delay_ms(300);
	//p=readNVRAM(0,56);nosabemos que onda
	//VFDposicion(0,2);
	for(i=0;i<0x0A;i++)
	         p++;
	i=0;//NO mee lee el *p
	do{ if(*p!=a[i]){
		I2CliberarModulo();	
		   return FALSE;}
	p++;
	}while(i++<7);	 
	I2CliberarModulo();
	return TRUE;
}//fin e evaluar la memria NVRAM en el BIOS---------------------------


void init_Products(void){
	
	
}//fin en init Products-------------------------------------------------------------------------


/* METODO PRINCIPAL DE INICIALIZACION DE VARIABLES AL ENCENDER O REINICIAR EL EQUIPO
 * SACA LOS DATOS DE LA EEPROM  DE LA CACHE  Y LOS INSERTA EN LAS 
 * VARIABLES DE PRODUCTO DE LA RAM
 * */
void init_MemoVars(void){//init vars from the eeprom
unsigned char 	*p,*p2,i;	
Dword word32;    //disponemos de 128kbytes
//unsigned short int address;//tama�o de las variables del sistema
unsigned char buffer[PROD_VAR_SIZE];//buffer para escribir variables del sistema
unsigned char TestSetup[]={"1Test SetUp\n\0"};

    indiceProducto=1;//producto Set TestUp, first run.
    modificado=NOP;//variable que indica que no se ha modfificado la configuracion en el menu
    realTimeError=CODE_ERROR_0000;//NO HAY ningun error
    
    //PRIMER VEZ QUE SE ENCIENDE LA PROCESADORA+++++++++++++++++++++++++++++++++++++++++++++++++
    if(readEEPROMbyte(STATUS_FACTORY_ADD)!=STATUS_FACTORY){//Es la primera vez que lo encienden
   //ESPACIO A+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    	 writeEEPROMbyte2(STATUS_FACTORY_ADD,STATUS_FACTORY);//escribimos byte de FactoryReset
    	 if(readEEPROMbyte(STATUS_FACTORY_ADD)!=STATUS_FACTORY)
    		    realTimeError=CODE_ERROR_EEPROM_BYTE1;
    	 
    	 //Comenzamos a llenar Variables del Sistema POR PRIMERA VEZ
   //ESPACIO B++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    	 
    	 p=&buffer[0];p2=p;
    	 *p=indiceProducto=1;                       //00H  Test SetUp
    	 *(p+1) =EntradasSistemaReg.aux1='0';       //01h COMINEZAN variables en ORDEN de MEMORIA NO REVOLVER QUITAR O PONER����
    	 *(p+2) =EntradasSistemaReg.aux2='0';       //02h variables en ORDEN de MEMORIA NO REVOLVER QUITAR O PONER����
    	 *(p+3) =EntradasSistemaReg.fotocel='0';    //03h		   
    	 *(p+4) =EntradasSistemaReg.producto='0';   //04h
    	 *(p+5) =EntradasSistemaReg.rechazo='0';    //05h variables en ORDEN de MEMORIA NO REVOLVER QUITAR O PONER����
    	 *(p+6) =EntradasSistemaReg.taco='0';       //06h variables en ORDEN de MEMORIA NO REVOLVER QUITAR O PONER����	 
    	 *(p+7) =IDcomm='0';                        //07h
    	 *(p+8) =Alta=1;                            //08h devision es uno 
    	 *(p+9) =Media=1;                           //09h ultimo digito de la frecuencia seleccionada
    	 *(p+10)=Baja=1;                            //0AH
    	 *(p+11)=CuentaProducto='0';                //0BH 
    	 *(p+12)=ControlContrasena1='0';            //0CH
    	 *(p+13)=ControlContrasena2='0';            //0DH
    	 *(p+14)=ControlContrasena3='0';            //0Eh
    	 *(p+15)=ControlContrasena4='0';            //0FH
    	 *(p+16)=Control_de_usuario='0';            //10H MENU_ADMINISTRATIVO
    	 *(p+17)=Guardia='1';                       //11H MENU_ADMINISTRATIVO
    	 *(p+18)=tipo_deMaquina='P';              
    	 *(p+19)=errorAnalogoPerm=PERMITIR;         //17H  INGENIERIA GRACIDA2
    	 *(p+20)=ReporteProductoPerm=PERMITIR;
    	 *(p+21)=PSUIOconfig=PERMITIR;             //16H  INGENIERIA GRACIDA2
   //       >^<----EL ULTIMO NUMERO DEBE coincidir con SISTEM_VAR_SIZE+1
    	 //escribimos las variables del sistema bloque B
    	 writeEEPROMblock(SYSTEM_VAR_ADD,SYSTEM_VAR_SIZE,p);//escribimos variables del sistema
    	 p2=readEEPROMblock(SYSTEM_VAR_ADD,SYSTEM_VAR_SIZE);//leemos para confirmar
    	 for(i=0;i<SYSTEM_VAR_SIZE;i++)
    		 if(*(p2+i)!=*(p+i)){
    			 realTimeError=CODE_ERROR_EEPROM_BLOQUE1;
    			 break;}
    //ESPACIO  C++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    	 //Product Vars Selected CACHE Assigning
    	 p2=&TestSetup[0];
    	 AsignVarProdAndGetPointer(p,p2);
    	 	  writeEEPROMblock(PROD_CACHE_VAR_ADD,PROD_VAR_SIZE,p);//escribimos variables de producto en cache
    	 	  p2=readEEPROMblock(PROD_CACHE_VAR_ADD,PROD_VAR_SIZE);//leemos para confirmar
    	 	  for(i=0;i<PROD_VAR_SIZE;i++)
    	 		 if(*(p2+i)!=*(p+i)){
    	 	     	realTimeError=CODE_ERROR_EEPROM_BLOQUE2;
    	 	       	break;} 
       //ESPACIO "D" DE LA VARIABLE Test-SetUp  PRODUCTO  "D" ++++++++++++++++++++++++++++++++++++++++++++++++++++
    	 	  //Pasamos el producto en cache a TestSetUP
    	 	  writeEEPROMblock(PROD_VAR0_ADD,PROD_VAR_SIZE,p);//escribimos var de cache a TestSetUp SPACE
    	 	  p2=readEEPROMblock(PROD_VAR0_ADD,PROD_VAR_SIZE);//leemos para confirmar
    	 	  for(i=0;i<PROD_VAR_SIZE;i++)
    	 		  if(*(p2+i)!=*(p+i)){
    	 			 realTimeError=CODE_ERROR_EEPROM_BLOQUE3;
    	 			 break;}
    	 	  
    	 	  
    	 	  
          }//if fin de es la primera vez que se enciende la procesadora
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    else{// El Sistema YA ESTA INIZIALIZADO DE ANTES., 
    //ESPACIO "B"  Leemos Variables del Sistema y las cargamos
    	p=&buffer[0];
    	p=readEEPROMblock(SYSTEM_VAR_ADD,SYSTEM_VAR_SIZE);//leemos variables de sistema
    	               indiceProducto=*p;                  //00H  Test SetUp
    	EntradasSistemaReg.aux1=     *(p+1);       //01h COMINEZAN variables en ORDEN de MEMORIA NO REVOLVER QUITAR O PONER����
    	EntradasSistemaReg.aux2=     *(p+2);       //02h variables en ORDEN de MEMORIA NO REVOLVER QUITAR O PONER����
    	EntradasSistemaReg.fotocel=  *(p+3);    //03h		   
    	EntradasSistemaReg.producto= *(p+4);   //04h
    	EntradasSistemaReg.rechazo=  *(p+5);  //05h variables en ORDEN de MEMORIA NO REVOLVER QUITAR O PONER����
    	EntradasSistemaReg.taco=     *(p+6);     //06h variables en ORDEN de MEMORIA NO REVOLVER QUITAR O PONER����	 
    	IDcomm=                      *(p+7);  //07h
    	Alta=                        *(p+8);    //08h devision es uno 
    	Media=                       *(p+9);    //09h ultimo digito de la frecuencia seleccionada
    	Baja=                        *(p+10);    //0AH
    	CuentaProducto=              *(p+11);  //0BH 
    	ControlContrasena1=          *(p+12);  //0CH
    	ControlContrasena2=          *(p+13);  //0DH
    	ControlContrasena3=          *(p+14);  //0Eh
    	ControlContrasena4=          *(p+15);  //0FH
    	Control_de_usuario=          *(p+16);  //10H MENU_ADMINISTRATIVO
    	Guardia=                     *(p+17);      //11H MENU_ADMINISTRATIVO
    	tipo_deMaquina=              *(p+18);
    	errorAnalogoPerm=            *(p+19);
    	ReporteProductoPerm=         *(p+20);
    	PSUIOconfig=                 *(p+21);
    	   //                           >^<----EL ULTIMO NUMERO DEBE coincidir con SISTEM_VAR_SIZE+1 
      	//Si esta seleccionado Test SetUp Mandamos el Producto 1 a cache
    	//if(indiceProducto==1){//Esta seleccionado el Producto=Test SetuP?
    	     p=readEEPROMblock(PROD_VAR0_ADD,PROD_VAR_SIZE);//leemos ESPACIO "D" CACHE
    	     //writeEEPROMblock(PROD_CACHE_VAR_ADD,PROD_VAR_SIZE,p);//pasamos el ESPACIO "D" al "C"
    	     //readEEPROMblock(PROD_CACHE_VAR_ADD,PROD_VAR_SIZE,p2);
    	     //for(i=0;i<PROD_VAR_SIZE;i++)
    	     //	 if(*(p2+i)!=*(p+i)){//comprobamos que se haya transferido  D->C
    	     //     realTimeError=CODE_ERROR_EEPROM_BLOQUE4;
             //     break;}  NO HACE FALTA ESRIBIR CACHE A TEST-SETUP, porque solo se transfiere cuando cambiamos de producto
    	     //bajamos los datos de la CACHE a las variables
    	     downloadPointer2ProductVars(p);
    	         	
    }//FIN else, SISTEMA YA SE INICIALIZO  ++++++++++++++++++++++++++++++++++++++++++++++++++++++
}//FIN INIT MEMO VARS+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//FIN INIT MEMO VARS+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//FIN INIT MEMO VARS+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//FIN INIT MEMO VARS+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    
/*dEL Menu del Nuevo Producto
 * guardamos el nuevo producto con los valores estandard vaciamos el producto actual
  de la cache a su espacion Pn � espacio TestSetUp si es iProd=1,     */
void saveNewProduct(unsigned char iProd){
unsigned char *p,*p2;
//Dword word32;    //disponemos de 128kbytes



       p=readEEPROMblock(CACHE_SPACE,PROD_VAR_SIZE);//leemos el cache=C
      //Guardar los valores del producto actual que esta en cache en su espacio Pn � Espacio Test SetUp
	  if(indiceProducto==1)//esta actualmete el TestSeptup puesto
		  //pasar los valores de Cache a TestSetUP_Space C->D
		  writeEEPROMblock(TEST_SETUP_SPACE,PROD_VAR_SIZE,p);//escribimos espacio D=TEstSEtUp  
	  //fin el producto que estaba antes era el Test SetUp
	  else//el seleccionado no es el SetUp es otro.
		  saveCacheProductPlaceEEPROM();	//sacamos el cache y metermos a su espacio Pn  
	  indiceProducto=iProd;//actualizamose el producto nuevo que ahora es el seleccionado
	  p2=&Text[0];//vamosa darle el nombre a cache
	  AsignVarProdAndGetPointer(p,p2);//escribimos el nombre p2 y obtenemos los valores estndard *p de las var RAM de prod
	  writeEEPROMblock(CACHE_SPACE,PROD_VAR_SIZE,p);//escribimos el cache con los valores p	    
	  writeEEPROM_Pn(indiceProducto,p);//escribimos producto en espacion Pn 
	  
	
}//fin de save ne product-------------------------------------------------

/*esta funcion  asigna la variable de nombre a las variables de producto en ram
 * y asigna los valores default a las variables ram de producto y tambien obtiene los apuntadores 
 * de las variables para vaciarlas en algun lado*/
void AsignVarProdAndGetPointer(unsigned char *p,unsigned char *T){
Dword word32;    //disponemos de 128kbytes
	
//Asisgnacion de VAriables de Producto POrPRIMERA VEZ A ESPACIO CACHE
		      	        *p=      name[0] =*T=NAME_INIT;       //48H
		      	 	    *(p+1)  =name[1] =*(T+1);
		      	 	    *(p+2)  =name[2] =*(T+2);
		      	 	    *(p+3)  =name[3] =*(T+3);
		      	 	    *(p+4)  =name[4] =*(T+4);
		      	 	    *(p+5)  =name[5] =*(T+5);
		      	 	    *(p+6)  =name[6] =*(T+6);
		      	 	    *(p+7)  =name[7] =*(T+7);
		      	 	    *(p+8)  =name[8] =*(T+8);
		      	 	    *(p+9)  =name[9] =*(T+9);
		      	 	    *(p+10) =name[10]=*(T+10);
		      	 	    *(p+11) =name[11]=*(T+11);
		      	 	    *(p+12) =name[12]=*(T+12);
		      	 	    *(p+13) =name[13]=*(T+13);
		      	    	*(p+14) =name[14]=*(T+14);
		      	 	    *(p+15) =name[15]=*(T+15);
		      	 	    *(p+16) =name[16]=*(T+16);
		      	 	    *(p+17) =name[17]=*(T+17);
		      	 	    *(p+18) =name[18]=*(T+18);
		      	 	    *(p+19) =name[19]=*(T+19);
		      	 	    *(p+20) =GananciaDriver=ALTA;     //13H  GANANCIA
		      	     	*(p+21) =GananciaAnaloga=ALTA;     //14H GANANCIA
		      	 		*(p+22) =filtroConfig=NORMAL;             //15H  FILTRO
		      	    	*(p+23) =BorrarContadores=APAGAR;
		      	 	    *(p+24) =phase=1;     
		      	 	    *(p+25) =phasefrac=5;         //1DH
		      	 	    *(p+26) =frecuenciaSeleccion=MEDIA;                           //1EH
		      	    	*(p+27) =MarcarAltura='0';                      //1FH
		      	 	    *(p+28) =GananciaDDS='0'; 
		      	 	    *(p+29) =ZoomDDS=98;               //29H	
		      	 	    *(p+30) =cuadritoDDS='0';             //2AH  
		      	 	     word32.Dwordx=Sensibilidad=140;
		      	 	     *(p+31)=word32.byte[0];
		      	 	     *(p+32)=word32.byte[1];
		      	 	     *(p+33)=word32.byte[2];
		      	 	     *(p+34)=word32.byte[3];
		      	 	     word32.Dwordx=Altura=32000;
		      	 	     *(p+35)=word32.byte[0];
		      	 	     *(p+36)=word32.byte[1];
		      	 	     *(p+37)=word32.byte[2];
		      	 	     *(p+38)=word32.byte[3];
		      	 	     word32.Dwordx=frecuency=1000000;                //MERGE variable 32bits frecuency	  
		      	 	     *(p+39)=word32.byte[0];
		      	 	     *(p+40)=word32.byte[1];
		      	 	     *(p+41)=word32.byte[2];
		      	 	     *(p+42)=word32.byte[3];
		      	   //       >^<----EL ULTIMO NUMERO DEBE coincidir con PROD_VAR_SIZE+1
}//fin de asignar valores default a las variables de producto en ram y su nombre especifico y obitene pointer 
//de las varibles-

/*Se usa esta funcion para actualizar los valores de una lectura de la EEPROM
 * en las variables de producto
 * */
void downloadPointer2ProductVars(unsigned char *p){
Dword word32;  
       name[0]            =*p;                   //48H
       name[1]            =*(p+1);               //49H
       name[2]            =*(p+2);             //4AH
       name[3]            =*(p+3);             //4BH
       name[4]            =*(p+4);             //4CH
       name[5]            =*(p+5);             //4DH
       name[6]            =*(p+6);             //4EH
       name[7]            =*(p+7);             //4FH
       name[8]            =*(p+8);             //50H
       name[9]            =*(p+9);             //51H
       name[10]           =*(p+10);            //52H
       name[11]           =*(p+11);             //53H
       name[12]           =*(p+12);              //54H
       name[13]           =*(p+13);              //55H       
       name[14]           =*(p+14);              //56H
       name[15]           =*(p+15);              //57H
       name[16]           =*(p+16);              //58H
       name[17]           =*(p+17);              //59H
       name[18]           =*(p+18);              //5AH
       name[19]           =*(p+19);              //5BH
       GananciaDriver     =*(p+20);     //13H  GANANCIA
       GananciaAnaloga    =*(p+21);     //14H GANANCIA
       filtroConfig       =*(p+22);             //15H  FILTRO
       BorrarContadores   =*(p+23);
       phase              =*(p+24);
       phasefrac          =*(p+25);         //1DH
       frecuenciaSeleccion=*(p+26);                           //1EH
       MarcarAltura       =*(p+27);                   //1FH
       GananciaDDS        =*(p+28); 
       ZoomDDS            =*(p+29);              //29H	
       cuadritoDDS        =*(p+30);             //2AH  
       word32.byte[0]     =*(p+31);
       word32.byte[1]     =*(p+32);
       word32.byte[2]     =*(p+33);
       word32.byte[3]     =*(p+34);
       Sensibilidad=word32.Dwordx;
       word32.byte[0]     =*(p+35);
       word32.byte[1]     =*(p+36);
       word32.byte[2]     =*(p+37);
       word32.byte[3]     =*(p+38);
       Altura=word32.Dwordx;
       word32.byte[0]     =*(p+39);
       word32.byte[1]     =*(p+40);
       word32.byte[2]     =*(p+41);
       word32.byte[3]     =*(p+42);
       frecuency=word32.Dwordx;
    	         //       >^<----EL ULTIMO NUMERO DEBE coincidir con PROD_VAR_SIZE+1  
}//fin del la descarg del apuntador en las varibles de producto actual----------------------

/* downloading the var product to the pointer to be saved */
void downloadProductVars2Pointer(unsigned char *p){
	Dword word32;  	
                *p=     name[0];
    	 	    *(p+1) =name[1];            //49H
    	 	    *(p+2) =name[2];            //4AH
    	 	    *(p+3) =name[3];            //4BH
    	 	    *(p+4) =name[4];            //4CH
    	 	    *(p+5) =name[5];            //4DH
    	 	    *(p+6) =name[6];            //4EH
    	 	    *(p+7) =name[7];            //4FH
    	 	    *(p+8) =name[8];            //50H
    	 	    *(p+9) =name[9];            //51H
    	 	    *(p+10) =name[10];            //52H
    	 	    *(p+11) =name[11];              //53H
    	 	    *(p+12) =name[12];              //54H
    	 	    *(p+13) =name[13];              //55H
    	    	*(p+14) =name[14];              //56H
    	 	    *(p+15) =name[15];              //57H
    	 	    *(p+16) =name[16];              //58H
    	 	    *(p+17) =name[17];              //59H
    	 	    *(p+18) =name[18];              //5AH
    	 	    *(p+19) =name[19];              //5BH
    	 	    *(p+20) =GananciaDriver;     //13H  GANANCIA
    	     	*(p+21) =GananciaAnaloga;     //14H GANANCIA
    	 		*(p+22) =filtroConfig;             //15H  FILTRO
    	    	*(p+23) =BorrarContadores;
    	 	    *(p+24) =phase;     
    	 	    *(p+25) =phasefrac;         //1DH
    	 	    *(p+26) =frecuenciaSeleccion;                           //1EH
    	    	*(p+27) =MarcarAltura;                      //1FH
    	 	    *(p+28) =GananciaDDS; 
    	 	    *(p+29) =ZoomDDS;               //29H	
    	 	    *(p+30) =cuadritoDDS;             //2AH  
    	 	     word32.Dwordx=Sensibilidad;
    	 	     *(p+31)=word32.byte[0];
    	 	     *(p+32)=word32.byte[1];
    	 	     *(p+33)=word32.byte[2];
    	 	     *(p+34)=word32.byte[3];
    	 	     word32.Dwordx=Altura;
    	 	     *(p+35)=word32.byte[0];
    	 	     *(p+36)=word32.byte[1];
    	 	     *(p+37)=word32.byte[2];
    	 	     *(p+38)=word32.byte[3];
    	 	     word32.Dwordx=frecuency;                //MERGE variable 32bits frecuency	  
    	 	     *(p+39)=word32.byte[0];
    	 	     *(p+40)=word32.byte[1];
    	 	     *(p+41)=word32.byte[2];
    	 	     *(p+42)=word32.byte[3];
    	   //       >^<----EL ULTIMO NUMERO DEBE coincidir con PROD_VAR_SIZE+1
}//fin de download product variable to pointer to be saved--------------------------------

//MEMORIA ES DE 128Kbytes=1F400h
void writeEEPROMblock(unsigned long int add,unsigned char buffSize,unsigned char *p){
unsigned char j;
unsigned long int i;
	             
                   for(i=add,j=0;i<(add+buffSize);i++,j++)
	                    EEPROM[i]=*(p+j);
	
}//fin de la escritura por bloques del driver de escritura EEPROM+++++++++++++++++++++++++++

void EEPROMmonitor(unsigned char issue){
	
	
	       //meter el issue en una fifo
	    //y monitorear NAME_INIT para descargar las variables  ala cache
	
}//fin activate eeprom monitor


//escribimos el apuntador en el espacion de memoria de producto indicado por iProd
void writeEEPROM_Pn(unsigned char iProd, unsigned char *p){
	 if(iProd==0)
		  return;
     writeEEPROMblock(PROD_VAR0_ADD+(PROD_VAR_SIZE*(iProd-1)),PROD_VAR_SIZE,p); 
}//fin de escritura en el espacio Pn de productos  iProd=1 -> Settestup,


//Leemos todos los bytes de un producto en particular, desde el Pn=1(testsetup a Pn)
unsigned char *readEEPROM_Pn(unsigned char iProd){
unsigned long add;
	if(iProd==0)
		 return;
    add=PROD_VAR0_ADD+(PROD_VAR_SIZE*(iProd-1));
	return (readEEPROMblock(add,PROD_VAR_SIZE));
}//fin de leer los bytes de un producto en particular--------------------------


//MEMORIA ES DE 128Kbytes=1F400h
unsigned char *readEEPROMblock(unsigned long int add,unsigned char buffSize){
static unsigned char buffer[PROD_VAR_SIZE],j;
unsigned long int i;
           
           for(i=add,j=0;i<(add+buffSize);i++,j++)
                  buffer[j]=EEPROM[i];
	       return &buffer[0];
}//fin de la escritura por bloques del driver de escritura EEPROM+++++++++++++++++++++++++++

void writeEEPROMbyte2(unsigned long int add,unsigned char byte){
                 EEPROM[add]=byte;        	
}//fin de la escritura por bloques del driver de escritura EEPROM+++++++++++++++++++++++++++

//MEMORIA ES DE 128Kbytes=1F400h
unsigned char readEEPROMbyte(unsigned long int add){	
             
return EEPROM[add];
}//fin de la escritura por bloques del driver de escritura EEPROM+++++++++++++++++++++++++++






void configModificado(unsigned char m){// encapsula la variable de configracion modificada	
	modificado=m;	//se modifico una configuracion del contexto m
}// fin controlador de configuracion modificada----------------------------------------------------- 


void MemoEEPROM_DDS(unsigned operacion,unsigned char contexto1,unsigned char mode){//con CONTROL DE DDS
     MemoEEPROM(operacion,contexto1);
	 if(mode==RESET_DDS_PWG)
		init_DDS(0);//se cambia la frecuecia en la analoga
}//fin memor EEPROM para inizializar el DDS-PWG--------------------------------------------------------


/*  IMPORTANTE: EL NUMERO DE BYTES "_SIZE" TIENE QUE COINCIDIR CON EL NUMERO DE ESCRITURAS O POINTERS
 *   dar de alta en VFDmenu las constantes de la pantalla y el numero de size de vfdmenu debe conicidir con el 
 *   pointer de aqui arriba
 * */
void MemoEEPROM(unsigned operacion,unsigned char contexto1){//leer la eeprom y reatuarar valores a las variables  
unsigned char *p;//tama�o maximo de bytes a guardar
unsigned long int addressVar; //direccion donde se va escribir o leer de determinado producto
 Dword word32;
//unsigned char dat[10]; // ESCRITURA Y LECTRURA ES POR PANTALLA  <<---NOTA!!!!!!!!!!!!
     addressVar=(unsigned long int)(contexto1+(indiceProducto-1)*PRODUCT_SIZE);
	switch(contexto1){//ES POR PANTALLA NO POR VARIABLE INDIVIDUAL
       case CONFIGURAR_ENTRADAS_DE_SISTEMA:/*aqui va procedimiento para resturar*/ 
							if(operacion==RESTAURAR){//restaurar, cambio la variable y se arrepintio
								   p=readEEPROM(addressVar,CONFIGURAR_ENTRADAS_DE_SISTEMA_SIZE);
								   EntradasSistemaReg.aux1=*p;
								   EntradasSistemaReg.aux2=*(p+1);
								   EntradasSistemaReg.fotocel=*(p+2);		   
								   EntradasSistemaReg.producto=*(p+3);
								   EntradasSistemaReg.rechazo=*(p+4);
								   EntradasSistemaReg.taco=*(p+5);  
								   I2CliberarModulo();}//ya pueden usar el modulo otros proc//fin config ent sistema restaurar	
							else{  //SAVE seccion
								   p=getPointerI2CBuffTx(CAT2401);
								   *p=EntradasSistemaReg.aux1;
								   *(p+1)=EntradasSistemaReg.aux2;
								   *(p+2)=EntradasSistemaReg.fotocel;		   
								   *(p+3)=EntradasSistemaReg.producto;
								   *(p+4)=EntradasSistemaReg.rechazo;
								   *(p+5)=EntradasSistemaReg.taco;
								   writeEEPROM(p,addressVar,CONFIGURAR_ENTRADAS_DE_SISTEMA_SIZE);}
     					      break;//fin SAVE
       case ID_COMUNICACIONES:if(operacion==RESTAURAR){/*IDcomm=0;aqui va procedimiento para resturar*/ 
    	                            p=readEEPROM(addressVar,ID_COMUNICACIONES_SIZE);
    	                            IDcomm=*p;
    	                            I2CliberarModulo();}//ya pueden usar el modulo}
                              else{p=getPointerI2CBuffTx(CAT2401);
                            	   *p=IDcomm;
                            	   writeEEPROM(p,addressVar,ID_COMUNICACIONES_SIZE);}
                              break;
       case CONTROL_DE_FRECUENCIA://Alta=5;Media=6;Baja=0;/*aqui va procedimiento para resturar*/ break;//--en-desarollo
    	                      if(operacion==RESTAURAR){
    	                    	    p=readEEPROM(addressVar,CONTROL_DE_FRECUENCIA_SIZE);
    	                    	    Alta=*p;
    	                    	    Media=*(p+1);
    	                    	    Baja=*(p+2);
    	                    	    I2CliberarModulo();}//ya pueden usar el modulo}
    	                      else{p=getPointerI2CBuffTx(CAT2401);
    	                    	   *p=Alta;
    	                    	   *(p+1)=Media;
    	                    	   *(p+2)=Baja;
    	                    	   writeEEPROM(p,addressVar,CONTROL_DE_FRECUENCIA_SIZE);
    	                    	   init_DDS(0);//NO DESCOMENTAR FALLA SAVE PRODUCT//se cambia la frecuecia en la analoga
    	                      }break;              

       case INFORMACION_DE_USUARIO: //CuentaProducto=APAGAR;break; 
    	                          if(operacion==RESTAURAR){
    	                        	  p=readEEPROM(addressVar,INFORMACION_DE_USUARIO_SIZE);
    	                        	  CuentaProducto=*p;
    	                        	  I2CliberarModulo();}//ya pueden usar el modulo}
    	                          else{p=getPointerI2CBuffTx(CAT2401);
    	                        	   *p=CuentaProducto;
    	                        	   writeEEPROM(p,addressVar,INFORMACION_DE_USUARIO_SIZE);}
    	                          break;
       case CONTROL_PASSWORD://ControlContrasena1=NO;ControlContrasena2=NO;
                             //ControlContrasena3=NO;ControlContrasena4=NO;break;
                             if(operacion==RESTAURAR){
                            	  p=readEEPROM(addressVar,CONTROL_PASSWORD_SIZE);
                            	  ControlContrasena1=*p;
                            	  ControlContrasena2=*(p+1);
                            	  ControlContrasena3=*(p+2);
                            	  ControlContrasena4=*(p+3);
                            	  I2CliberarModulo();}//ya pueden usar el modulo}
                             else{p=getPointerI2CBuffTx(CAT2401);
                            	  *p=ControlContrasena1;
                            	  *(p+1)=ControlContrasena2;
                            	  *(p+2)=ControlContrasena3;
                            	  *(p+3)=ControlContrasena4;
                            	  writeEEPROM(p,addressVar,CONTROL_PASSWORD_SIZE);}
                            break;
       case MENU_ADMINISTRATIVO:// 	Control_de_usuario='0';Guardia='1'; break;
    	                    if(operacion==RESTAURAR){
    	                    	p=readEEPROM(addressVar,MENU_ADMINISTRATIVO_SIZE);
    	                    	Control_de_usuario=*p;
    	                    	Guardia=*(p+1);
    	                    	I2CliberarModulo();}//ya pueden usar el modulo}
    	                    else{p=getPointerI2CBuffTx(CAT2401);
    	                    	 *p=Control_de_usuario;
    	                    	 *(p+1)=Guardia;
    	                    	 writeEEPROM(p,addressVar,MENU_ADMINISTRATIVO_SIZE);}
    	                    break;
       case TIPO_DE_MAQUINA://  tipo_deMaquina=SINGLE_875_286; break;
    	                    if(operacion==RESTAURAR){
    	                    	p=readEEPROM(addressVar,TIPO_DE_MAQUINA_SIZE);
    	                    	tipo_deMaquina=*p;
    	                    	I2CliberarModulo();}//ya pueden usar el modulo}
    	       	            else{p=getPointerI2CBuffTx(CAT2401);
    	       	                 *p=tipo_deMaquina; 	 
    	       	                 writeEEPROM(p,addressVar,TIPO_DE_MAQUINA_SIZE); }
    	       	            break;
       case GANANCIA_: //GananciaDriver=AJUSTABLE; GananciaAnaloga=MEDIA; break;
    	                   if(operacion==RESTAURAR){
    	                	   p=readEEPROM(addressVar,GANANCIA__SIZE);
    	                	   GananciaDriver=*p;
    	                	   GananciaAnaloga=*(p+1);
    	                	   I2CliberarModulo();}//ya pueden usar el modulo}
    	       	           else{p=getPointerI2CBuffTx(CAT2401);
    	       	                *p=GananciaDriver;    	 
    	       	                *(p+1)=GananciaAnaloga;
    	       	                //writeEEPROM(p,addressVar,GANANCIA__SIZE); 
    	       	                init_AnalogGainControl();}//activar salidas fisicas hacia Analoga Board
    	       	           break;
       case FILTRO_: //filtroConfig=NORMAL; break;
    	                 if(operacion==RESTAURAR){
    	                	 p=readEEPROM(addressVar,FILTRO__SIZE);
    	                	 filtroConfig=*p;
    	                	 I2CliberarModulo();}//ya pueden usar el modulo}
    	       	        else{p=getPointerI2CBuffTx(CAT2401);
    	       	             *p=filtroConfig;
    	       	             writeEEPROM(p,addressVar,FILTRO__SIZE);}       	 
    	       	        break; 
       case INGENIERIA_GRACIDA2: //PSUIOconfig=PERMITIR; errorAnalogoPerm=PERMITIR; 
                                 //ReporteProductoPerm='0';  break;
    	               if(operacion==RESTAURAR){
    	            	   p=readEEPROM(addressVar,INGENIERIA_GRACIDA2_SIZE);
    	            	   PSUIOconfig=*p;
    	            	   errorAnalogoPerm=*(p+1);
    	            	   ReporteProductoPerm=*(p+2);
    	            	   I2CliberarModulo();}//ya pueden usar el modulo
    	       	       else{p=getPointerI2CBuffTx(CAT2401);
    	       	            *p=PSUIOconfig;
    	       	            *(p+1)=errorAnalogoPerm;
    	       	            *(p+2)=ReporteProductoPerm;
    	       	            writeEEPROM(p,addressVar,INGENIERIA_GRACIDA2_SIZE);}
    	       	       break;
       case AJUSTE_PARAMETRICO_DE_PRODUCTO: //Sensibilidad=20;
                                            //BorrarContadores=APAGAR; break;
    	              if(operacion==RESTAURAR){
    	            	  p=readEEPROM(addressVar,AJUSTE_PARAMETRICO_DE_PRODUCTO_SIZE);
    	            	  word32.byte[0]=*p;
    	            	  word32.byte[1]=*(p+1);
    	            	  word32.byte[2]=*(p+2);
    	            	  word32.byte[3]=*(p+3);  	            	  
    	            	  Sensibilidad=word32.Dwordx;
    	            	  BorrarContadores=*(p+4);
    	            	  phase=*(p+5);
    	            	  phasefrac=*(p+6);
    	            	  I2CliberarModulo();
    	            	  if(Sensibilidad>32000)
    	            	  		 Sensibilidad=32000;}
    	       	      else{p=getPointerI2CBuffTx(CAT2401);
    	       	           word32.Dwordx=Sensibilidad;
    	       	           *p=word32.byte[0];
    	       	           *(p+1)=word32.byte[1];
    	       	           *(p+2)=word32.byte[2];
    	       	           *(p+3)=word32.byte[3];           
    	       	           *(p+4)=BorrarContadores;
    	       	           *(p+5)=phase;
    	       	           *(p+6)=phasefrac;
    	       	           writeEEPROM(p,addressVar,AJUSTE_PARAMETRICO_DE_PRODUCTO_SIZE);}
    	       	      break;
       case FRECUENCIA_SELECT: //frecuenciaSeleccion=MEDIA; frecuency=280000; break;
    	              if(operacion==RESTAURAR){
    	            	  p=readEEPROM(addressVar,FRECUENCIA_SELECT_SIZE);
    	            	  frecuenciaSeleccion=*p;
    	            	  word32.byte[0]=*(p+1);
    	            	  word32.byte[1]=*(p+2);
    	            	  word32.byte[2]=*(p+3);
    	            	  word32.byte[3]=*(p+4);
    	            	  frecuency=word32.Dwordx;
    	            	  I2CliberarModulo();}
    	       	     else{p=getPointerI2CBuffTx(CAT2401);//escribir variables de frecuencia seleccion
    	       	          *p=frecuenciaSeleccion;
    	       	          word32.Dwordx=frecuency;
    	       	          *(p+1)=word32.byte[0];
    	       	          *(p+2)=word32.byte[1];
    	       	          *(p+3)=word32.byte[2];
    	       	          *(p+4)=word32.byte[3];
    	       	          writeEEPROM(p,addressVar,FRECUENCIA_SELECT_SIZE);
    	       	          init_DDS(0); //NO DESCOMENTAR//se cambia la frecuencia del DDS xq se acepto guardar los cambios hechos
	                }break;
       case RELOJ_DE_SISTEMA: saveTimeNVRAM(); //a�o,mes,dia,fecha,hora,minutos,segundos;break; 
    	                    break;
       case PARAMETROS_DE_DETECCION://1<Altura<32000, MarcarAtura=No|Si
    	              if(operacion==RESTAURAR){
    	                 p=readEEPROM(addressVar,PARAMETROS_DE_DETECCION_SIZE);
    	                 word32.byte[0]=*p;
    	                 word32.byte[1]=*(p+1);
    	                 word32.byte[2]=*(p+2);
    	                 word32.byte[3]=*(p+3);
    	                 Altura=word32.Dwordx;
    	                 MarcarAltura=*(p+4);
    	                 I2CliberarModulo();
    	                 p=readEEPROM(addressVar,FRECUENCIA_SELECT_SIZE);
    	                 frecuenciaSeleccion=*p;
    	                 word32.byte[0]=*(p+1);
    	                 word32.byte[1]=*(p+2);
    	                 word32.byte[2]=*(p+3);
    	                 word32.byte[3]=*(p+4);
    	                 frecuency=word32.Dwordx;
    	                 I2CliberarModulo();
    	                 p=readEEPROM(addressVar,AJUSTE_PARAMETRICO_DE_PRODUCTO_SIZE);
    	                 word32.byte[0]=*p;
    	                 word32.byte[1]=*(p+1);
    	                 word32.byte[2]=*(p+2);
    	                 word32.byte[3]=*(p+3);  	            	  
    	                 Sensibilidad=word32.Dwordx;
    	                 BorrarContadores=*(p+4);
    	                 phase=*(p+5);
    	                 phasefrac=*(p+6);
    	                 I2CliberarModulo(); 
    	                 if(Altura>32000)
    	                 		Altura=32000;
    	                 if(Sensibilidad>32000)
    	                 		 Sensibilidad=32000;}
    	              else{p=getPointerI2CBuffTx(CAT2401);
    	                    word32.Dwordx=Altura;
    	                   *p=word32.byte[0];
    	                   *(p+1)=word32.byte[1];
    	                   *(p+2)=word32.byte[2];
    	                   *(p+3)=word32.byte[3];
    	                   *(p+4)=MarcarAltura;
    	                   writeEEPROM(p,addressVar,PARAMETROS_DE_DETECCION_SIZE);
    	                  p=getPointerI2CBuffTx(CAT2401);//traemos la dir del buffer de I2C tx
    	                  *p=frecuenciaSeleccion;
    	                  word32.Dwordx=frecuency;
    	                 *(p+1)=word32.byte[0];
    	                 *(p+2)=word32.byte[1];
    	                 *(p+3)=word32.byte[2];
    	                 *(p+4)=word32.byte[3];
    	                 writeEEPROM(p,addressVar,FRECUENCIA_SELECT_SIZE);
    	                 p=getPointerI2CBuffTx(CAT2401);
    	                 word32.Dwordx=Sensibilidad;
    	                 *p=word32.byte[0];
    	                 *(p+1)=word32.byte[1];
    	                 *(p+2)=word32.byte[2];
    	                 *(p+3)=word32.byte[3];           
    	                 *(p+4)=BorrarContadores;
    	                 *(p+5)=phase;
    	                 *(p+6)=phasefrac;
    	                 writeEEPROM(p,addressVar,AJUSTE_PARAMETRICO_DE_PRODUCTO_SIZE);
    	                 //init_DDS(0); NO DESCOMENTAR//se cambia la frecuencia del DDS xq se acepto guardar los cambios hechos
	                 }break;
       case PANTALLA_DDS:
    	              if(operacion==RESTAURAR){
    	            	 p=readEEPROM(addressVar,PANTALLA_DDS_SIZE);
    	            	 GananciaDDS=*p;
    	            	 ZoomDDS=*(p+1);
    	            	 cuadritoDDS=*(p+2);
    	            	 I2CliberarModulo();//para poder usar el i2c otravez
    	            	 MemoEEPROM(RESTAURAR,AJUSTE_PARAMETRICO_DE_PRODUCTO);}
    	              else{p=getPointerI2CBuffTx(CAT2401);
    	            	   *p=GananciaDDS;
    	            	   *(p+1)=ZoomDDS;
    	            	   *(p+2)=cuadritoDDS;
    	            	   writeEEPROM(p,addressVar,PANTALLA_DDS_SIZE);
    	            	   word32.Dwordx=Sensibilidad;
    	            	   *p=word32.byte[0];
    	            	   *(p+1)=word32.byte[1];
    	            	   *(p+2)=word32.byte[2];
    	            	   *(p+3)=word32.byte[3];           
    	            	   *(p+4)=BorrarContadores;
    	            	   *(p+5)=phase;
    	            	   *(p+6)=phasefrac;
    	            	   writeEEPROM(p,addressVar,AJUSTE_PARAMETRICO_DE_PRODUCTO_SIZE);
    	            	   p=getPointerI2CBuffTx(CAT2401);
    	            	   word32.Dwordx=Altura;
    	            	   *p=word32.byte[0];
    	            	   *(p+1)=word32.byte[1];
    	            	   *(p+2)=word32.byte[2];
    	            	   *(p+3)=word32.byte[3];
    	            	   *(p+4)=MarcarAltura;
    	            	   writeEEPROM(p,addressVar,PARAMETROS_DE_DETECCION_SIZE);}
    	              break;
          case NOMBRE_PRODUCTO:
        	             if(operacion==RESTAURAR){
        	      	        	p=readEEPROM(addressVar,NOMBRE_PRODUCTO_SIZE);
        	      	        	name[0]=*p;
        	      	          	name[1]= *(p+1);
        	      	        	name[2]= *(p+2);
        	      	        	name[3]= *(p+3);
        	      	        	name[4]= *(p+4);
        	      	        	name[5]= *(p+5);
        	      	        	name[6]= *(p+6);
        	      	        	name[7]= *(p+7);
        	      	        	name[8]= *(p+8);
        	      	        	name[9]= *(p+9);
        	      	        	name[10]=*(p+10);
        	      	        	name[11]=*(p+11);
        	      	        	name[12]=*(p+12);
        	      	        	name[13]=*(p+13);
        	      	        	name[14]=*(p+14);
        	      	        	name[15]=*(p+15);
        	      	        	name[16]=*(p+16);
        	      	        	name[17]=*(p+17);
        	      	        	name[18]=*(p+18);
        	      	        	name[19]=*(p+19);
        	      	            I2CliberarModulo();}//para poder usar el i2c otravez
        	      	      else{p=getPointerI2CBuffTx(CAT2401);
        	      	            *p=name[0];
        	      	            *(p+1) =name[1];
        	      	            *(p+2) =name[2];
        	      	            *(p+3) =name[3];
        	      	            *(p+4) =name[4];
        	      	            *(p+5) =name[5];
        	      	            *(p+6) =name[6];
        	      	            *(p+7) =name[7];
        	      	            *(p+8) =name[8];
        	      	            *(p+9) =name[9];
        	      	            *(p+10)=name[10];
        	      	            *(p+11)=name[11];
        	      	            *(p+12)=name[12];
        	      	            *(p+13)=name[13];
        	      	            *(p+14)=name[14];
        	      	            *(p+15)=name[15];
        	      	            *(p+16)=name[16];
        	                	*(p+17)=name[17];
        	                	*(p+18)=name[18];
        	                	*(p+19)=name[19];
        	      	            writeEEPROM(p,addressVar,NOMBRE_PRODUCTO_SIZE);}
        	            break;      
          case ERROR_LISTA://codigo incompleto
        	            switch(operacion){//codigo incompleto
        	              case RESTAURAR: //falta debug
        	            	             break;
        	            	   
        	              case CODE_ERROR_0001:
        	              case CODE_ERROR_0002:
        	              case CODE_ERROR_0003:
        	              case CODE_ERROR_0004:
        	              case CODE_ERROR_0005:	  
        	            	                   break;
        	              default:break;
        	            }//fin switch
        	          if(operacion==RESTAURAR){//codigo incompleto
        	        	p=readEEPROM(0,0);  //falta debug
        	        	  
        	          }  
        	          break;//fin ERROR_LISTA
         case PARTE_11:
        	           init_AnalogGainControl();//actualiza las salidas para controlar la nueva Analoga
        	           break;//fin PARTE 11
         case BORRAR_PRODUCTO:
        	          if(operacion==RESTAURAR)
        	        	  break;//no vamos a borrar Producto nada,
        	          else//vamos a borrar Producto
        	        	  writeEEPROMbyte2(PROD_VAR0_ADD+(PROD_VAR_SIZE*(igxm-1)),0);//se borra el bit �, para borrar el prod con esto 
        	          break;
         case COPY_PRODUCTO:
        	         if(operacion==RESTAURAR)//no queremos copiar nada
        	        	 break;
        	         else{//si estamos seguros de copiar el producto
        	        	  if(igxm==indiceProducto)//copiar el actual selected}
        	        		  downloadiProductVars2Cache();//bajamos las variables a la cache
        	        	  else 
        	        		  getiProductEEPROM2vars(igxm); //sacamos el iProduct  a las variables
        	        	  setVar2iProduct(igxm4);//guardamos las variables en el espacio seleccionado 		  
        	        	    break;} 
        	         break;//fin COPY_PRODUCTO
        	          
       default:break;       	 
  }//fin switch contexto----------------------------------------------------------------------------	

}//fin restaurar contexto---------------------------------------------------------------------------


/*save the space CACHE  to the  spacE product Pn*/
void saveCacheProductPlaceEEPROM(void){
unsigned char *p;	
    p=readEEPROMblock(PROD_CACHE_VAR_ADD,PROD_VAR_SIZE);
    writeEEPROMblock(PROD_VAR0_ADD+(PROD_VAR_SIZE*(indiceProducto-1)),PROD_VAR_SIZE,p);
	   
	
}//fin de save CACHE memory in Product space Memoriy EEPROM

/*valida que el nombre seleccionado no se un espacio en blanco o que haya sido guardado con anterioridad */
unsigned char validarName(unsigned char iProduct){
unsigned char *p;	
	     p=readEEPROMblock(PROD_VAR0_ADD+(PROD_VAR_SIZE*(iProduct-1)),PROD_VAR_SIZE);//leemos el producto que queremos seleccionar
	     if(*p==NAME_INIT)
	          return TRUE;
	     else return FALSE;	 
	     
}//fin de validar producto seleccionado para activar aver si no es solo espacios o nombre basura

/* sacamos el valor de las variables de producto del espacio Pn a las variables*/
void getiProductEEPROM2vars(unsigned char iProduct){
unsigned char *p;
unsigned long int add;
         add=PROD_VAR0_ADD+(PROD_VAR_SIZE*(iProduct-1));
         p=readEEPROMblock(add,PROD_VAR_SIZE);
         downloadPointer2ProductVars(p);
}//fin download the EEPROM vars product to PRODUCT vars


//mandar las variables de producto al Producto Pn 
void setVar2iProduct(unsigned char iProduct){
unsigned char buffer[PROD_VAR_SIZE],*p;
         p=&buffer[0];
	     downloadProductVars2Pointer(p);
	     writeEEPROMblock(PROD_VAR0_ADD+(PROD_VAR_SIZE*(iProduct-1)),PROD_VAR_SIZE,p);
}//fin de pasar las variables al producto Pn directamente---------------------------------


unsigned char *getiProductEEPROM(unsigned char iProduct){
         return(readEEPROMblock(PROD_VAR0_ADD+(PROD_VAR_SIZE*(iProduct-1)),PROD_VAR_SIZE));
}//fin download the EEPROM vars to pointer


/* bajamos las variables del producto a la area de CACHE EEPROM*/
void downloadiProductVars2Cache(void){
unsigned char *p;
unsigned char buffer[PROD_VAR_SIZE];//buffer para escribir variables del sistema
          p=&buffer[0];
          downloadProductVars2Pointer(p);
          writeEEPROMblock(PROD_CACHE_VAR_ADD,PROD_VAR_SIZE,p); 
}///fin del methodo que descarga las variables de PRoducto ala CACHE eeprom


unsigned char  *memoEEPROM_SelProd(unsigned char iProduct){
//unsigned char *p;//tama�o maximo de bytes a guardar
//unsigned long int addressVar; //direccion donde se va escribir o leer de determinado producto	
//static unsigned char name1[NOMBRE_PRODUCTO_SIZE];	//debug revisar si debe ser static
//unsigned char contexto1=NOMBRE_PRODUCTO;
      //  addressVar=(unsigned long int)(contexto1+(iProduct-1)*PRODUCT_SIZE);
	    
            return (readEEPROM_Pn(iProduct));
 //return &name1[0];           
}//leer el nombre del producto del indice dado-------------------------------------------------------
        

/*Esta funcion me va a dar el indice del espacio vacio para poner un nuevo producto, y vamos a buscar del
 * indice actual hacia arriba o hacia abajo  y regresamos el indice para 
 * */
unsigned char  memoEEPROM_SearchPlace(unsigned char iniProd){
unsigned char *p;//tama�o maximo de bytes a guardar
//unsigned long int addressVar; //direccion donde se va escribir o leer de determinado producto	
unsigned char name1[NOMBRE_PRODUCTO_SIZE];	
unsigned char contexto1=NOMBRE_PRODUCTO;//buscamos el nombre de producto
unsigned char iProduct;
      //de cual iProduct empezamos
     for(iProduct=iniProd;iProduct<CANTIDAD_PRODUCTOS+1;iProduct++){	    
          	p=getiProductEEPROM(iProduct);
            name1[0]=*p;
            if(name1[0]!=NAME_INIT)
            	   return iProduct;}
 return (CANTIDAD_PRODUCTOS+1);//si pasa esto es porque no hay espacio para mas productos           
}//leer el nombre del producto del indice dado-------------------------------------------------------

unsigned char  memoEEPROM_SearchPlaceUP(unsigned char iniProd){
unsigned char *p;//tama�o maximo de bytes a guardar
//unsigned long int addressVar; //direccion donde se va escribir o leer de determinado producto	
unsigned char name1[NOMBRE_PRODUCTO_SIZE];	
unsigned char contexto1=NOMBRE_PRODUCTO;//buscamos el nombre de producto
unsigned char iProduct;
      //de cual iProduct empezamos
     if(iniProd==2)//es el segundo iProd
    	 return 0;  //que se vaa a a la X
     for(iProduct=iniProd-1;iProduct>1;iProduct--){	    
          	p=getiProductEEPROM(iProduct);
            name1[0]=*p;
            if(name1[0]!=NAME_INIT)
                 return iProduct;}
 return 0;//si pasa esto es porque no hay espacio para mas productos           
}//leer el nombre del producto del indice dado-------------------------------------------------------




//igual que restaurar. restaura las variables en la eeprom
//unsigned char getEntradadeTaco(void){return(EntradadeTaco); }//fin get entrada de tacho porque el compilador no agarra las variables extern
//void setEntradadeTaco(unsigned char n){EntradadeTaco=n;}
//unsigned char getmodificado(void){return modificado;}
//void setmodificado(unsigned char m){ modificado=m;}

void initMemoria_y_Restaurar(void){//inizializar memoria y restaurar a estado de fabrica
	
	/*  CODIGO EN DESARROLLO */
	
	
}// fin init memoria y restaurar----------------------------------------------------

//variabes encasuladas en el methodo --------------
/*
unsigned char getEntradasSistemaReg(unsigned char v){
	     switch(v){ 
	        case TACO: return(EntradasSistemaReg.taco);break;
	        case FOTOCEL:return(EntradasSistemaReg.fotocel);break;
	        case RECHAZO:return(EntradasSistemaReg.rechazo);break;
	        case PRODUCTO:return(EntradasSistemaReg.producto);break;
	        case AUX1:return(EntradasSistemaReg.aux1);break;    
	        case AUX2:return(EntradasSistemaReg.aux2);break;    
}//get char entradas sistema registro----------------------------------------------
	     
void setTaco(unsigned char n){EntradasSistemaReg }	     
*/


void init_ErrorsLogs(void){
unsigned char 	*p;	
//Dword word32;    //disponemos de 128kbytes
	modificado=NOP;//variable que indica que no se ha modfificado la configuracion en el menu
	p=readEEPROM(0,LASTADDRESS_VARS_EEPROM);
	
}// initizializar errors logs--------------------------------------------------------------------------

void init_Semaforos(void){
	 //SEMdisplayEEPROM=VERDE+1;//en rojo
	  Sem.operacion=VERDE; 
	
}//fin inizializar los semaforos de los hilos


//funciones que se ejecutan en el hilo principal una vez cuando alguien las activa
void ControladorOperativoPrincipal(void){ 
	
	 if(Sem.operacion==READ_EEPROM_DISPLAY){//se ejecuta la funcion de despliegue de la EEPROM
		  disable_keyboard_IRQ();
		  Sem.operacion=ROJO; //ejecutar el despliegue de los datos leidos
		  //Sem.p=readEEPROMbyte(10);
		  Sem.operacion=DISPLAY_EEPROM;}
		  
		  
}//fin del controlador operativo principal de funciones que se e---------------------------


//para ejecutar h se ejecuta timer1
void ControladorOperativoTemporizado(void){
	
 switch(Sem.operacion){
	case DISPLAY_EEPROM:Sem.operacion=ROJO;
                     	displayEEPROMdata1(Sem.p);
                     	enable_keyboard_IRQ();
                     	Sem.operacion=VERDE;
		                break;// fin DISPLAY_EEPROM
	default:break;
	  }//fin switch principal


}//fin del controlador Operativo Temporizado--------------------------------------------




